package fr.dwils.userservice.mapper;

import fr.dwils.userservice.dto.UserRequestDTO;
import fr.dwils.userservice.dto.UserResponseDTO;
import fr.dwils.userservice.model.User;

public class UserMapper {

    public static User toEntity(UserRequestDTO dto) {
        return User.builder()
                .email(dto.getEmail())
                .password(dto.getPassword())
                .username(dto.getUsername())
                .build();
    }

    public static UserResponseDTO toDTO(User user) {
        return UserResponseDTO.builder()
                .id(user.getId())
                .email(user.getEmail())
                .username(user.getUsername())
                .build();
    }
}
