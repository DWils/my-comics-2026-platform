package fr.dwils.userservice.service;

import fr.dwils.userservice.dto.LoginRequestDTO;
import fr.dwils.userservice.dto.LoginResponseDTO;

public interface AuthService {
    LoginResponseDTO login(LoginRequestDTO dto);
}
