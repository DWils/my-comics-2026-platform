package fr.dwils.userservice.service.impl;

import fr.dwils.userservice.dto.LoginRequestDTO;
import fr.dwils.userservice.dto.LoginResponseDTO;
import fr.dwils.userservice.model.User;
import fr.dwils.userservice.repository.UserRepository;
import fr.dwils.userservice.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;

    @Override
    public LoginResponseDTO login(LoginRequestDTO dto) {

        User user = userRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!user.getPassword().equals(dto.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        // TEMPORARY - no JWT yet
        String fakeToken = "FAKE-TOKEN-" +user.getId();

        return LoginResponseDTO.builder()
                .token(fakeToken)
                .email(user.getEmail())
                .username(user.getUsername())
                .build();
    }
}
