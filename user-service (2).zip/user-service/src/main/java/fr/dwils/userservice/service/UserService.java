package fr.dwils.userservice.service;

import fr.dwils.userservice.dto.UserRequestDTO;
import fr.dwils.userservice.dto.UserResponseDTO;
import fr.dwils.userservice.model.User;

import java.util.List;

public interface UserService {
    UserResponseDTO createUser(UserRequestDTO user);
    UserResponseDTO getUser(Long id);

}
