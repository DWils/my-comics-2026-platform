package fr.dwils.userservice.service.impl;

import fr.dwils.userservice.dto.UserRequestDTO;
import fr.dwils.userservice.dto.UserResponseDTO;
import fr.dwils.userservice.mapper.UserMapper;
import fr.dwils.userservice.model.User;
import fr.dwils.userservice.repository.UserRepository;
import fr.dwils.userservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public UserResponseDTO createUser(UserRequestDTO dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        User user = UserMapper.toEntity(dto);
        User saved = userRepository.save(user);

        return UserMapper.toDTO(saved);
    }

    @Override
    public UserResponseDTO getUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return UserMapper.toDTO(user);
    }

//    @Override
//    public List<User> getAllUsers() {
//        return userRepository.findAll();
//    }
}
